import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SearchResultsComponentComponent } from './search-results-component/search-results-component.component';
import { LoginComponentComponent } from './login-component/login-component.component';



const routes: Routes = [
  { path: 'search-results-component.component', component: SearchResultsComponentComponent },
  { path : 'login-component.component' , component:LoginComponentComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
