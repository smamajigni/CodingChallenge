import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpClientModule} from '@angular/common/http';
import {searchServices} from './services/searchServices';
import {loginServices} from './services/loginServices';
import { MatTableModule, MatPaginatorModule, MatSortModule } from '@angular/material';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SearchDataComponentComponent } from './search-data-component/search-data-component.component';
import { SearchResultsComponentComponent } from './search-results-component/search-results-component.component';
import { HeaderComponentComponent } from './shared/layouts/header-component/header-component.component';
import { FooterComponentComponent } from './shared/layouts/footer-component/footer-component.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LoginComponentComponent } from './login-component/login-component.component';
import { BodyComponentComponent } from './body-component/body-component.component';


@NgModule({
  declarations: [
    AppComponent,
    SearchDataComponentComponent,
    SearchResultsComponentComponent,
    HeaderComponentComponent,
    FooterComponentComponent,
    LoginComponentComponent,
    BodyComponentComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    HttpClientModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    FormsModule, 
    ReactiveFormsModule,
  ],
  providers: [searchServices,
    loginServices],
  bootstrap: [AppComponent]
})
export class AppModule { }
