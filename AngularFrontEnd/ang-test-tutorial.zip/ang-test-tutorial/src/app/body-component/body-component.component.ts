import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-body-component',
  templateUrl: './body-component.component.html',
  styleUrls: ['./body-component.component.css']
})
export class BodyComponentComponent implements OnInit {
  loginUrl = './login-component.component';

  constructor( private router: Router) {
    
    this.router.navigate([this.loginUrl]);
   }

  ngOnInit() {
    this.router.navigate([this.loginUrl]);
  }

}
