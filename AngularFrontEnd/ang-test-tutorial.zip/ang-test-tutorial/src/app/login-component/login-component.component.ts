import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { loginServices } from '../services/loginServices';
import { Router, ActivatedRoute } from '@angular/router';
import { first } from 'rxjs/operators';
import { User} from '../models/user';
import { isDefined } from '@angular/compiler/src/util';


@Component({
  selector: 'app-login-component',
  templateUrl: './login-component.component.html',
  styleUrls: ['./login-component.component.css']
})
export class LoginComponentComponent implements OnInit {
  loginForm: FormGroup;
  loading = false;
  submitted = false;
  returnUrl: string;
  loggedUser :any;
  invalidColor;

  constructor(
      private formBuilder: FormBuilder,
      private route: ActivatedRoute,
      private router: Router,
      private authenticationService: loginServices,
  ) {
      this.invalidColor='white';
  }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
        username: ['', Validators.required],
        password: ['', Validators.required]
    });

    // get return url for the search page
    this.returnUrl =  '/search-results-component.component.html';
}
   // convenience getter for easy access to form fields
   get f() { return this.loginForm.controls; }


   onSubmit() {
    this.submitted = true;
    console.log("in the onsubmit function")
      // Return  if form is invalid
    if (this.loginForm.invalid) {
        return
    }

    this.loading = true;
    this.authenticationService.login(this.f.username.value, this.f.password.value);
    this.loggedUser = JSON.parse(localStorage.getItem('currentUser'));
   // console.log(localStorage.getItem('currentUser'))
    //console.log(this.loggedUser.id)

    if(isDefined(this.loggedUser.id) && this.loggedUser.id > 0 )
    {
        console.log("valid user" + this.loggedUser.id +' naviagte url is '+ this.returnUrl)
        this.router.navigate(['./search-results-component.component']);       

    }
    else
    {
        
        //this user does not exist in our list..so we show error
        console.log("invalid user" + this.loggedUser.id )
        this.loading = false;
        //Show the invalid user text
        this.invalidColor='red';

    }
     
}

}






