import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchDataComponentComponent } from './search-data-component.component';

describe('SearchDataComponentComponent', () => {
  let component: SearchDataComponentComponent;
  let fixture: ComponentFixture<SearchDataComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchDataComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchDataComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
