import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-search-data-component',
  templateUrl: './search-data-component.component.html',
  styleUrls: ['./search-data-component.component.css']
})
export class SearchDataComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
