import { Component, OnInit,ViewChild,Input } from '@angular/core';
import {MatPaginator} from '@angular/material/paginator';
import {MatTableDataSource} from '@angular/material/table';
import {searchServices} from '../services/searchServices';
import { FormBuilder } from '@angular/forms';
import { FormsModule} from '@angular/forms';
import {User} from '../models/user';


/**
 * @title Table with search results
 */
@Component({
  selector: 'app-search-results-component',
  templateUrl: './search-results-component.component.html',
  styleUrls: ['./search-results-component.component.css'],
  providers : [searchServices]
})

export class SearchResultsComponentComponent implements OnInit {
  public noOfMilliSeconds;
  displayedColumns: string[] = ['id', 'firstname_t', 'lastname_t', 'age_i','gender_t','treatmenttype_t','treatmentnotes_t'];
 dataSource  = new MatTableDataSource<DentalRecords>();;
 myInput;
 currentLoggedUser : User;
 userName : string;
 userType : string;
 resultData :any;


  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  
  //Constructor
  constructor(private _searchService: searchServices) { 
    //Get the current logged in user from localstorage
    this.currentLoggedUser= JSON.parse(localStorage.getItem('currentUser'));
    this.userName = this.currentLoggedUser.firstName + " " + this.currentLoggedUser.lastName;
    this.userType = this.currentLoggedUser.usertype;
  }

  ngOnInit() {
   this.getDentalRecords();
    this.dataSource.paginator = this.paginator;
  }

  renderGrid(objGridData:DentalRecords[]){
    this.dataSource= new MatTableDataSource<DentalRecords>(objGridData);
    this.dataSource.paginator = this.paginator;
   }

  getDentalRecords() {
   
    this._searchService.getAllSearchData().subscribe(
      // the first argument is a function which runs on success
      data => { 
        this.resultData  = data;
        this.dataSource = new MatTableDataSource<DentalRecords>(this.resultData.response.docs);
        this.dataSource.paginator = this.paginator;
       // console.log(data)
        //console.log(data.response.numFound)
       this.noOfMilliSeconds = this.resultData.responseHeader.qTime;
        return this.resultData.response.docs;
      
      },
      // the second argument is a function which runs on error
      err => console.error(err),
      // the third argument is a function which runs on completion
      () => console.log('Done loading all dental records')
    );
  }

  onSubmit() {
    // Search for specific search query
    console.log("passed the search query ...." + this.myInput )
    this._searchService.getSearchData(this.myInput+"*").subscribe(
      // the first argument is a function which runs on success
      data => { 
        this.resultData  = data;
        this.dataSource = new MatTableDataSource<DentalRecords>(this.resultData.response.docs);
        this.dataSource.paginator = this.paginator;
       // console.log(data)
       // console.log(data.response.numFound)
       this.noOfMilliSeconds = this.resultData.responseHeader.qTime;
        return this.resultData.response.docs;
      
      },
      // the second argument is a function which runs on error
      err => console.error(err),
      // the third argument is a function which runs on completion
      () => console.log('Done loading all dental records')
    );
  }
}



export interface DentalRecords {
  id: number;
  firstname_t: string;
  lastname_t: string;
  age_i: number;
  gender_t : string;
  treatmenttype_t : string;
  treatmentnotes_t :string;

}

