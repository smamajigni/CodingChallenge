import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { User } from '../models/user';
import { isDefined } from '@angular/compiler/src/util';


let users = [{ id: 1, firstName: 'Admin', lastName: 'Admin', username: 'admin', password: 'admin' ,usertype:'admin'},
{ id: 2, firstName: 'User1', lastName: 'Morrison', username: 'user1', password: 'user1' ,usertype:'admin'},
{ id: 3, firstName: 'User2', lastName: 'Watmore', username: 'user2', password: 'user2',usertype:'user' },
{ id: 3, firstName: 'User3', lastName: 'Milton', username: 'user3', password: 'user3',usertype:'user' }
];

@Injectable()
export class loginServices {
    private currentUserSubject: BehaviorSubject<User>;
    public currentUser: Observable<User>;
    public user;

    constructor(private http: HttpClient) {
        this.currentUserSubject = new BehaviorSubject<User>(JSON.parse(localStorage.getItem('currentUser')));
        this.currentUser = this.currentUserSubject.asObservable();
    }

    public get currentUserValue(): User {
        return this.currentUserSubject.value;
    }

    login(username, password) {
        
        this.user = this.authenticate({ username, password });
        console.log(' Returned user is '+ this.user)
    
        if(isDefined(this.user.id)) {
            console.log('this user exists')
            localStorage.setItem('currentUser', JSON.stringify(this.user));
            this.currentUserSubject.next(this.user);
            
        }
        else
        {
            console.log('this user does not exist')
            localStorage.removeItem('currentuser');
            

        }
              
    }

    logout() {
        // remove user from local storage and set current user to null
        localStorage.removeItem('currentUser');
        this.currentUserSubject.next(null);
    }

    authenticate({ username, password }) {
        console.log('Calling authenticate method with user '+ username + '  with password '+ password)
       
        const user = users.find(x => x.username === username && x.password === password);
        console.log('user found '+ user)
        if (!user) return ({
            id: 0,
            username: null,
            firstName: null,
            lastName: null,
            usertype : null,
            token: 'Username or password is incorrect'
        });
        return ({
            id: user.id,
            username: user.username,
            firstName: user.firstName,
            lastName: user.lastName,
            usertype : user.usertype,
            token: 'fake-jwt-token'
        })
    }

}

