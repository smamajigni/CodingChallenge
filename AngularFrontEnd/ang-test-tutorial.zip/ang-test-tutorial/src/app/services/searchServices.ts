import {NgModule} from  '@angular/core';
import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import {environment} from 'src/environments/environment';
import { isUndefined } from 'util';
import { stringify } from '@angular/compiler/src/util';
@Injectable()
export class searchServices {
  headerOptions;
  constructor(private http:HttpClient) {  
   
    this.headerOptions=new HttpHeaders({ 'Content-Type': 'application/json' });    
  }
  //Function to get all data
  public getAllSearchData=()=>{   
    let options={headers:this.headerOptions};
    return this.http.get(environment.solrConfig.url,options);
  }

  //Function to get specific search data
  public getSearchData=(queryString?:string)=>{   
    let options={headers:this.headerOptions};
    return this.http.get(environment.solrConfig.url+"/"+queryString,options);
  }

}