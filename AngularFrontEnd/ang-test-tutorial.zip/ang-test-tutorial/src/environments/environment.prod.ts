export const environment = {
  production: true,
  solrConfig:{
    url:"http://localhost/SearchAPI/api/search"
  },
  loginAuth:{
    adminPass:"admin",
    userPass:"user"
  }
};
