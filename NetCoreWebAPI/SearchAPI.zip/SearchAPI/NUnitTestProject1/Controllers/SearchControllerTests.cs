﻿using NUnit.Framework;




namespace searchAPITests.Controllers
{
    class SearchControllerTests
    {
        SearchController searchController;

        [Setup]
        public void Setup()
        {
            _searchController = new SearchController();
        }

        [Test]
        public void SearchTest()
        {
            Assert.Pass();
        }
    }
}
