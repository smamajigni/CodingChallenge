﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Web;
using SearchAPI.Models;
using SearchAPI.Services;
using Microsoft.Extensions.Logging;
using RestSharp;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Microsoft.AspNetCore.Cors;

namespace SearchAPI.Controllers
{
    /// <summary>
    /// Controller class for searching dental records
    /// </summary>
     [EnableCors("AllowSpecificOrigin")]
    [Route("api/[controller]")]
    [ApiController]
    public class SearchController : ControllerBase
    {

        protected readonly ILogger _logger;
        private readonly SearchAPIAppSettings appSettings;



        public SearchController(IOptions<SearchAPIAppSettings> settings)
        {
            ILoggerFactory loggerFactory = new LoggerFactory().AddConsole();

            ILogger logger = loggerFactory.CreateLogger<SearchController>();
            _logger = logger;
            appSettings = settings.Value;


        }

        /// <summary>
        /// Entry point to the search without a query
        /// </summary>
        /// <param name="queryString"> search string</param>
        /// <returns>Dental record object</returns>
        // GET api/search/<querystring>
        [HttpGet("{queryString}")]
        [ProducesResponseType(200)]
        [ProducesResponseType(500)]
        public ActionResult<DentalRecord.Rootobject> getSearchResults(string queryString)
        {
            //Call the search from Solr and return the search values
            _logger.Log(LogLevel.Error, "*********Calling the getSearchResults in the SearchController*************");
            _logger.LogInformation("****************************Test Logging **************************************************");

            SearchServices searchServices = new SearchServices();
            return searchServices.getSearchResults(queryString, appSettings.SolrURL, _logger);
        }

        /// <summary>
        /// Entry point to the search without a query
        /// </summary>
        /// <returns>dentalrecord object</returns>
        // GET api/search/<querystring>
        [HttpGet]
        [ProducesResponseType(200)]
        [ProducesResponseType(500)]
        public ActionResult<DentalRecord.Rootobject> getSearchResults()
        {
            //Call the search from Solr and return the search values
            _logger.Log(LogLevel.Information, "Calling the getSearchResults in the SearchController");
            _logger.LogInformation("****************************Default Test Logging **************************************************");
            SearchServices searchServices = new SearchServices();
            return searchServices.getSearchResults("", appSettings.SolrURL, _logger);      
        }

        [HttpPost]
    
        [ProducesResponseType(500)]
        public void Post([FromBody] JObject value)
        {
            try {
                //Call the Add record method to store the dental record
                DentalRecord.Doc newDoc = new DentalRecord.Doc();
                newDoc.id = value["id"].ToString();
                newDoc.firstname_t = value["firstname"].ToString();
                newDoc.lastname_t = value["lastname"].ToString();
                newDoc.age_i = Convert.ToInt32(value["age"]);
                newDoc.gender_t = value["gender"].ToString();
                newDoc.treatmenttype_t = value["treatmenttype"].ToString();
                newDoc.treatmentnotes_t = value["treatmentnotes"].ToString();

                //Call the add dental method from the services class,get the location of the sample data from the appsettings
                SearchServices.addDentalRecord(newDoc, appSettings.DataFilePath,_logger, appSettings.SolrURL);

            }
            catch(Exception ex)
            {
                _logger.LogError("Error --" + ex.Message);
            }
        }

    }
}