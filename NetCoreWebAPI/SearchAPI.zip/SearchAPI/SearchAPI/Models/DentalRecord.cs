﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SolrNet.Attributes;

namespace SearchAPI.Models
{
    public class DentalRecord
    {
        public class Rootobject
        {
            public Responseheader responseHeader { get; set; }
            public Response response { get; set; }
        }

        public class Responseheader
        {
            public int status { get; set; }
            public int QTime { get; set; }
            public Params _params { get; set; }
        }

        public class Params
        {
            public string q { get; set; }
            public string indent { get; set; }
            public string wt { get; set; }
        }

        public class Response
        {
            public int numFound { get; set; }
            public int start { get; set; }
            public Doc[] docs { get; set; }
        }

        public class Doc
        {

            [SolrUniqueKey("id")]
            // public string DentalId { get; set; }
            public string id { get; set; }


            [SolrField("firstname_t")]
            public string firstname_t { get; set; }

            [SolrField("lastname_t")]
            public string lastname_t { get; set; }

            [SolrField("age_i")]
            //  public int Age { get; set; }
            public int age_i { get; set; }

            [SolrField("gender_t")]
            public string gender_t { get; set; }

            [SolrField("treatmenttype_t")]
            public string treatmenttype_t { get; set; }

            [SolrField("treatmentnotes_t")]
            public string treatmentnotes_t { get; set; }
        }

 
    }
}
