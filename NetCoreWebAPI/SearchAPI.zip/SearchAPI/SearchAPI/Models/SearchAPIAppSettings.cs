﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SearchAPI.Models
{
    public class SearchAPIAppSettings
    {
        /// <summary>
        /// Application name
        /// </summary>
        public string ApplicationName { get; set; }
        
        /// <summary>
        /// Version of the application
        /// </summary>
        public string Version { get; set; }
        
        /// <summary>
        /// File path where the sample data files are stored
        /// </summary>
        public string DataFilePath { get; set; }

        /// <summary>
        /// The url where the Solr server is running
        /// </summary>
        public string SolrURL { get; set; }

    }
}
