﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SearchAPI.Models;
using System.Xml.Linq;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using RestSharp;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using Microsoft.Extensions.Logging;

namespace SearchAPI.Services
{
   
    public class SearchServices
    {
        /// <summary>
        /// Function to add dental record in xml format
        /// </summary>
        /// <param name="dentalDoc"> Dental record to be stored</param>
        /// <returns></returns>
        public static void addDentalRecord(DentalRecord.Doc dentalDoc, string dentalFilePath, ILogger _logger, string SolrURL)
        {
            try
            {
                               
                //Form the xml file name
                string dentalRecordFile = dentalFilePath + "NewDentalRecord_" + dentalDoc.id + ".xml";
             
                XElement docElement =
                    new XElement("doc",
                      new XElement("field", new XAttribute("name", "id"), (dentalDoc.id)),
                      new XElement("field", new XAttribute("name", "firstname"), (dentalDoc.firstname_t)),
                      new XElement("field", new XAttribute("name", "lastname"), (dentalDoc.lastname_t)),
                      new XElement("field", new XAttribute("name", "age"), dentalDoc.age_i),
                      new XElement("field", new XAttribute("name", "Gender"), dentalDoc.gender_t),
                      new XElement("field", new XAttribute("name", "treatmenttype"), dentalDoc.treatmenttype_t),
                      new XElement("field", new XAttribute("name", "treatmentnotes"), dentalDoc.treatmentnotes_t)); 

                XDocument doc = new XDocument(new XElement("add", docElement));
                doc.Save(dentalRecordFile);

                //Instantiate SolrServices
                SolrServices _solrServices = new SolrServices();
                _solrServices.addDocumentToSolr(dentalDoc, SolrURL);

            }
            catch(Exception ex)
            {
                //Lets throw the exception to be handled by the calling function
                throw ex;
            }
        }

        public DentalRecord.Rootobject getSearchResults(string searchQuery, string SolrURL, ILogger _logger)
        {
            DentalRecord.Rootobject jsonObject = new DentalRecord.Rootobject();
            try
            {

                RestClient client = new RestClient(SolrURL);
                RestRequest request = new RestRequest("/solr/dentalRecords/select");
                request.AddParameter("wt", "json");
                string qString = "firstname_t:" + searchQuery + " OR lastname_t:" + searchQuery + " OR treatmenttype_t:" + searchQuery + " OR treatmentnotes_t:" + searchQuery;
                if (!string.IsNullOrWhiteSpace(searchQuery)) request.AddParameter("q", qString);
                else request.AddParameter("q", "*:*");
                request.AddParameter("indent", "true");
                request.AddParameter("rows", "200");
                IRestResponse queryResult = client.Execute(request);

                //Using Linq
                JObject jsonUsingLinq = JObject.Parse(queryResult.Content.ToString());
                string resultsFound = (string)jsonUsingLinq["response"]["numFound"];
                _logger.Log(LogLevel.Information, "Found " + resultsFound + " results from the search query");

                //Paste as JSON classes
                jsonObject = JsonConvert.DeserializeObject<DentalRecord.Rootobject>(queryResult.Content.ToString());
            }
            catch (Exception ex)
            {
                _logger.Log(LogLevel.Error, ex.Message);
            }
            return jsonObject;
        }
    }
}
