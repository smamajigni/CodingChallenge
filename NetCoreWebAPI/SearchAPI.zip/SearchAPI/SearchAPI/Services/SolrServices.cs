﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SolrNet;
using SearchAPI.Models;
using Microsoft.Practices.ServiceLocation;

namespace SearchAPI.Services
{
    public class SolrServices
    {
        public void addDocumentToSolr(DentalRecord.Doc dentalRecord, string SolrURL)
        {
            try
            {
                SolrNet.Startup.Init<DentalRecord.Doc>(SolrURL + "solr/dentalRecords");

                ISolrOperations<DentalRecord.Doc> solr = ServiceLocator.Current.GetInstance<ISolrOperations<DentalRecord.Doc>>();

                //Add the dental record
                solr.Add(dentalRecord);

                //Commit
                solr.Commit();
            }
            catch(Exception ex)
            {
                throw ex;
            }


        }
    }

   
}
