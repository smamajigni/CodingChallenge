﻿using System;
using System.Collections.Generic;
using System.Text;
using SearchAPI.Controllers;
using SearchAPI.Models;
using NUnit.Framework;
using Microsoft.Extensions.Options;



namespace SearchAPITests
{
    class SearchControllerTests
    {
        
    }
}
