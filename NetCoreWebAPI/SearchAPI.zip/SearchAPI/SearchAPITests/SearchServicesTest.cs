﻿using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;
using SearchAPI.Services;
using SearchAPI.Models;
using Microsoft.Extensions.Logging;
using Moq;

namespace SearchAPITests
{
    [TestFixture]
    class SearchServicesTest
    {

        [Test]
        public void Test_getSearchResults_ResultType()
        {
            SearchServices searchServices = new SearchServices();
            //mocking the logger
            var mock = new Mock<ILogger<SearchServices>>();
            ILogger<SearchServices> logger = mock.Object;
            var result = searchServices.getSearchResults("test", "testurl", logger);
            Assert.That(result, Is.InstanceOf<DentalRecord.Rootobject>());
        }

      
        [Test]
        public void Test_getSearchResults_ResultCount()
        {
            SearchServices searchServices = new SearchServices();
            //mocking the logger
            var mock = new Mock<ILogger<SearchServices>>();
            ILogger<SearchServices> logger = mock.Object;

            //Negative test for incorrect url
            var result = searchServices.getSearchResults(" ", "http://localhost:1234/", logger);
            Assert.Null(result.response);

            //Negative test for incorrect test query
            var resultneg = searchServices.getSearchResults("12abc34", "http://localhost:8983/", logger);
            Assert.AreEqual(0, resultneg.response.docs.Length);

            //Test with valid address, we know we bring in 200 records 
            var result1 = searchServices.getSearchResults(" ", "http://localhost:8983/", logger);
            Assert.AreEqual(200, result1.response.docs.Length);

            //Test with a test query - we know there are atleast 200 records with Crowns
            var result2 = searchServices.getSearchResults("Crowns", "http://localhost:8983/", logger);
            Assert.AreEqual(200, result2.response.docs.Length);

            //Test with a test query - we know there are atleast 200 records with Sealants
            var result3 = searchServices.getSearchResults("Sealants", "http://localhost:8983/", logger);
            Assert.AreEqual(200, result3.response.docs.Length);

         
        }

               
        [Test]
        public void Test_addDentalRecord()
        {
            Assert.Pass();
        }


    }
}
