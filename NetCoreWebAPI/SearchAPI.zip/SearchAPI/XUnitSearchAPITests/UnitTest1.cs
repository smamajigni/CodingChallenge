using System;
using Xunit;

namespace XUnitSearchAPITests
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {

        }
    }
}
